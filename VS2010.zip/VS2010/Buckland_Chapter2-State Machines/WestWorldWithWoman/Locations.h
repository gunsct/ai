#ifndef LOCATIONS_H
#define LOCATIONS_H


enum location_type
{
  shack,
  goldmine,
  bank,
  saloon
};




//uncomment to send output to 'output.txt'
//#define TEXTOUTPUT




#endif