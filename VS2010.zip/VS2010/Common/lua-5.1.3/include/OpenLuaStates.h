#ifndef OPEN_LUA_STATES
#define OPEN_LUA_STATES

extern "C"
{
  #include <lua.h>
  #include <lualib.h>
  #include <lauxlib.h>
}



#endif