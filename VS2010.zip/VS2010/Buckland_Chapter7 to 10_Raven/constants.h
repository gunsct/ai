#ifndef CONSTANTS_H
#define CONSTANTS_H



const int WindowWidth  = 500;
const int WindowHeight = 500;
const int FrameRate    = 60;


#endif