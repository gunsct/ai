//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDR_MENU1                       101
#define ID_MENU_LOAD                    40001
#define IDM_MAP_LOAD                    40001
#define IDM_GAME_LOAD                   40001
#define IDM_NAVIGATION_SHOW_NAVGRAPH    40002
#define IDM_NAVIGATION_SHOW_PATH        40004
#define IDM_NAVIGATION_SMOOTH_PATHS_QUICK 40005
#define IDM_BOTS_SHOW_IDS               40006
#define IDM_BOTS_SHOW_HEALTH            40007
#define IDM_BOTS_SHOW_TARGET            40008
#define IDM_BOTS_SHOW_FOV               40009
#define IDM_BOTS_SHOW_SCORES            40010
#define IDM_BOTS_SHOW_GOAL_Q            40011
#define IDM_NAVIGATION_SHOW_INDICES     40012
#define IDM_MAP_ADDBOT                  40013
#define IDM_GAME_ADDBOT                 40013
#define IDM_MAP_REMOVEBOT               40014
#define IDM_GAME_REMOVEBOT              40014
#define IDM_NAVIGATION_SMOOTH_PATHS_PRECISE 40015
#define IDM_BOTS_SHOW_SENSED            40016
#define IDM_GAME_PAUSE                  40017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
